/*
 * Copyright (c) 2003-2012 JGoodies Karsten Lentzsch. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 *  o Neither the name of JGoodies Karsten Lentzsch nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jgoodies.validation.util;

import static com.jgoodies.common.base.Preconditions.checkArgument;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * Consists exclusively of static methods for validating input values
 * by testing and comparing single and multiple values.<p>
 *
 * The <a href="http://jakarta.apache.org/commons/lang.html">Jakarta Commons Lang</a>
 * library contains more classes and methods useful for validation.
 * The Utils string and character tests in this ValidationUtils class are
 * compatible with the Jakarta Commons Lang {@code StringUtils} methods.
 *
 * @author  Karsten Lentzsch
 * @version $Revision: 1.19 $
 *
 * @see Calendar
 */
public final class ValidationUtils {


    private ValidationUtils() {
        // Override default constructor; prevents instantiation.
    }


    // Length Tests ***********************************************************

    /**
     * Checks and answers if the given string has at least the
     * specified minimum length.
     * Strings that are {@code null} or contain only blanks have length 0.
     *
     * <pre>
     * ValidationUtils.hasMinimumLength(null,  2) == false
     * ValidationUtils.hasMinimumLength("",    2) == false
     * ValidationUtils.hasMinimumLength(" ",   2) == false
     * ValidationUtils.hasMinimumLength("   ", 2) == false
     * ValidationUtils.hasMinimumLength("Hi ", 2) == true
     * ValidationUtils.hasMinimumLength("Ewa", 2) == true
     * </pre>
     *
     * @param str   the string to check
     * @param min   the minimum length
     * @return {@code true} if the length is greater or equal to the minimum,
     *     {@code false} otherwise
     */
    public static boolean hasMinimumLength(String str, int min) {
        int length = str == null ? 0 : str.trim().length();
        return min <= length;
    }


    /**
     * Checks and answers if the given string is shorter than
     * the specified maximum length.
     * Strings that are {@code null} or contain only blanks have length 0.
     *
     * <pre>
     * ValidationUtils.hasMaximumLength(null,  2) == true
     * ValidationUtils.hasMaximumLength("",    2) == true
     * ValidationUtils.hasMaximumLength(" ",   2) == true
     * ValidationUtils.hasMaximumLength("   ", 2) == true
     * ValidationUtils.hasMaximumLength("Hi ", 2) == true
     * ValidationUtils.hasMaximumLength("Ewa", 2) == false
     * </pre>
     *
     * @param str   the string to check
     * @param max   the maximum length
     * @return {@code true} if the length is less than or equal to the minimum,
     *     {@code false} otherwise
     */
    public static boolean hasMaximumLength(String str, int max) {
        int length = str == null ? 0 : str.trim().length();
        return length <= max;
    }


    /**
     * Checks and answers if the length of the given string is in the
     * bounds as specified by the interval [min, max].
     * Strings that are {@code null} or contain only blanks have length 0.
     *
     * <pre>
     * ValidationUtils.hasBoundedLength(null,  1, 2) == false
     * ValidationUtils.hasBoundedLength("",    1, 2) == false
     * ValidationUtils.hasBoundedLength(" ",   1, 2) == false
     * ValidationUtils.hasBoundedLength("   ", 1, 2) == false
     * ValidationUtils.hasBoundedLength("Hi ", 1, 2) == true
     * ValidationUtils.hasBoundedLength("Ewa", 1, 2) == false
     * </pre>
     *
     * @param str   the string to check
     * @param min   the minimum length
     * @param max   the maximum length
     * @return {@code true} if the length is in the interval,
     *     {@code false} otherwise
     * @throws IllegalArgumentException if min > max
     */
    public static boolean hasBoundedLength(String str, int min, int max) {
        checkArgument(min <= max,
                "The minimum length must be less than or equal to the maximum length.");
        int length = str == null ? 0 : str.trim().length();
        return min <= length && length <= max;
    }


    // Character Validations **************************************************

    /**
     * Checks and answers if the given string contains only unicode letters.
     * {@code null} returns false,
     * an empty string ("") returns {@code true}.
     *
     * <pre>
     * ValidationUtils.isAlpha(null)   == false
     * ValidationUtils.isAlpha("")     == true
     * ValidationUtils.isAlpha("   ")  == false
     * ValidationUtils.isAlpha("abc")  == true
     * ValidationUtils.isAlpha("ab c") == false
     * ValidationUtils.isAlpha("ab2c") == false
     * ValidationUtils.isAlpha("ab-c") == false
     * </pre>
     *
     * @param str   the string to check, may be {@code null}
     * @return {@code true} if the string contains only unicode letters,
     *     and is non-{@code null}
     *
     * @since 1.2
     */
    public static boolean isAlpha(String str) {
        if (str == null) {
            return false;
        }
        for (int i = str.length() - 1; i >= 0; i--) {
            if (!Character.isLetter(str.charAt(i))) {
                return false;
            }
        }
        return true;
    }


    /**
     * Checks and answers if the given string contains only unicode letters
     * and space (' ').
     * {@code null} returns false,
     * an empty string ("") returns {@code true}.
     *
     * <pre>
     * ValidationUtils.isAlphaSpace(null)   == false
     * ValidationUtils.isAlphaSpace("")     == true
     * ValidationUtils.isAlphaSpace("   ")  == true
     * ValidationUtils.isAlphaSpace("abc")  == true
     * ValidationUtils.isAlphaSpace("ab c") == true
     * ValidationUtils.isAlphaSpace("ab2c") == false
     * ValidationUtils.isAlphaSpace("ab-c") == false
     * </pre>
     *
     * @param str   the string to check, may be {@code null}
     * @return {@code true} if the string contains only unicode letters
     *     and space, and is non-{@code null}
     *
     * @since 1.2
     */
    public static boolean isAlphaSpace(String str) {
        if (str == null) {
            return false;
        }
        for (int i = str.length() - 1; i >= 0; i--) {
            char c = str.charAt(i);
            if (!Character.isLetter(c) && c != ' ') {
                return false;
            }
        }
        return true;
    }


    /**
     * Checks and answers if the given string contains only
     * unicode letters or digits.
     * {@code null} returns false,
     * an empty string ("") returns {@code true}.
     *
     * <pre>
     * ValidationUtils.isAlphanumeric(null)   == false
     * ValidationUtils.isAlphanumeric("")     == true
     * ValidationUtils.isAlphanumeric("   ")  == false
     * ValidationUtils.isAlphanumeric("abc")  == true
     * ValidationUtils.isAlphanumeric("ab c") == false
     * ValidationUtils.isAlphanumeric("ab2c") == true
     * ValidationUtils.isAlphanumeric("ab-c") == false
     * ValidationUtils.isAlphanumeric("123")  == true
     * ValidationUtils.isAlphanumeric("12 3") == false
     * ValidationUtils.isAlphanumeric("12-3") == false
     * </pre>
     *
     * @param str   the string to check, may be {@code null}
     * @return {@code true} if the string contains only unicode letters
     *     or digits, and is non-{@code null}
     *
     * @since 1.2
     */
    public static boolean isAlphanumeric(String str) {
        if (str == null) {
            return false;
        }
        for (int i = str.length() - 1; i >= 0; i--) {
            if (!Character.isLetterOrDigit(str.charAt(i))) {
                return false;
            }
        }
        return true;
    }


    /**
     * Checks and answers if the given string contains only
     * unicode letters or digits or space (' ').
     * {@code null} returns false,
     * an empty string ("") returns {@code true}.
     *
     * <pre>
     * ValidationUtils.isAlphanumericSpace(null)   == false
     * ValidationUtils.isAlphanumericSpace("")     == true
     * ValidationUtils.isAlphanumericSpace("   ")  == true
     * ValidationUtils.isAlphanumericSpace("abc")  == true
     * ValidationUtils.isAlphanumericSpace("ab c") == true
     * ValidationUtils.isAlphanumericSpace("ab2c") == true
     * ValidationUtils.isAlphanumericSpace("ab-c") == false
     * ValidationUtils.isAlphanumericSpace("123")  == true
     * ValidationUtils.isAlphanumericSpace("12 3") == true
     * ValidationUtils.isAlphanumericSpace("12-3") == false
     * </pre>
     *
     * @param str   the string to check, may be {@code null}
     * @return {@code true} if the string contains only unicode letters,
     *     digits or space (' '), and is non-{@code null}
     *
     * @since 1.2
     */
    public static boolean isAlphanumericSpace(String str) {
        if (str == null) {
            return false;
        }
        for (int i = str.length() - 1; i >= 0; i--) {
            char c = str.charAt(i);
            if (!Character.isLetterOrDigit(c) && c != ' ') {
                return false;
            }
        }
        return true;
    }


    /**
     * Checks and answers if the given string contains only unicode digits.
     * A decimal point is not a unicode digit and returns {@code false}.
     * {@code null} returns false,
     * an empty string ("") returns {@code true}.
     *
     * <pre>
     * ValidationUtils.isNumeric(null)   == false
     * ValidationUtils.isNumeric("")     == true
     * ValidationUtils.isNumeric("   ")  == false
     * ValidationUtils.isNumeric("abc")  == false
     * ValidationUtils.isNumeric("ab c") == false
     * ValidationUtils.isNumeric("ab2c") == false
     * ValidationUtils.isNumeric("ab-c") == false
     * ValidationUtils.isNumeric("123")  == true
     * ValidationUtils.isNumeric("12 3") == false
     * ValidationUtils.isNumeric("12-3") == false
     * ValidationUtils.isNumeric("12.3") == false
     * </pre>
     *
     * @param str   the string to check, may be {@code null}
     * @return {@code true} if the string contains only unicode digits,
     *     and is non-{@code null}
     *
     * @since 1.2
     */
    public static boolean isNumeric(String str) {
        if (str == null) {
            return false;
        }
        for (int i = str.length() - 1; i >= 0; i--) {
            if (!Character.isDigit(str.charAt(i))) {
                return false;
            }
        }
        return true;
    }


    /**
     * Checks and answers if the given string contains only unicode digits
     * or space (' '). A decimal point is not a unicode digit and
     * returns {@code false}.
     * {@code null} returns false,
     * an empty string ("") returns {@code true}.
     *
     * <pre>
     * ValidationUtils.isNumericSpace(null)   == false
     * ValidationUtils.isNumericSpace("")     == true
     * ValidationUtils.isNumericSpace("   ")  == true
     * ValidationUtils.isNumericSpace("abc")  == false
     * ValidationUtils.isNumericSpace("ab c") == false
     * ValidationUtils.isNumericSpace("ab2c") == false
     * ValidationUtils.isNumericSpace("ab-c") == false
     * ValidationUtils.isNumericSpace("123")  == true
     * ValidationUtils.isNumericSpace("12 3") == true
     * ValidationUtils.isNumericSpace("12-3") == false
     * ValidationUtils.isNumericSpace("12.3") == false
     * </pre>
     *
     * @param str   the string to check, may be {@code null}
     * @return {@code true} if the string contains only unicode digits
     *     or space, and is non-{@code null}
     *
     * @since 1.2
     */
    public static boolean isNumericSpace(String str) {
        if (str == null) {
            return false;
        }
        for (int i = str.length() - 1; i >= 0; i--) {
            char c = str.charAt(i);
            if (!Character.isDigit(c) && c != ' ') {
                return false;
            }
        }
        return true;
    }


    // Date Validations *******************************************************

    /**
     * Determines and answers if the day of the given {@code Date}
     * is in the past.
     *
     * @param date   the date to check
     * @return {@code true} if in the past, {@code false} otherwise
     */
    public static boolean isPastDay(Date date) {
        Calendar in = new GregorianCalendar();
        in.setTime(date);
        Calendar today = getRelativeCalendar(0);
        return in.before(today);
    }


    /**
     * Determines and answers if the given {@code Date} is yesterday.
     *
     * @param date   the date to check
     * @return {@code true} if yesterday, {@code false} otherwise
     */
    public static boolean isYesterday(Date date) {
        Calendar in = new GregorianCalendar();
        in.setTime(date);
        Calendar yesterday = getRelativeCalendar(-1);
        Calendar today     = getRelativeCalendar( 0);
        return !in.before(yesterday)
             && in.before(today);
    }


    /**
     * Determines and answers if the given {@code Date} is today.
     *
     * @param date   the date to check
     * @return {@code true} if today, {@code false} otherwise
     */
    public static boolean isToday(Date date) {
        GregorianCalendar in = new GregorianCalendar();
        in.setTime(date);
        Calendar today    = getRelativeCalendar( 0);
        Calendar tomorrow = getRelativeCalendar(+1);
        return !in.before(today)
             && in.before(tomorrow);
    }


    /**
     * Determines and answers if the given {@code Date} is tomorrow.
     *
     * @param date   the date to check
     * @return {@code true} if tomorrow, {@code false} otherwise
     */
    public static boolean isTomorrow(Date date) {
        GregorianCalendar in = new GregorianCalendar();
        in.setTime(date);
        Calendar tomorrow = getRelativeCalendar(+1);
        Calendar dayAfter = getRelativeCalendar(+2);
        return !in.before(tomorrow)
             && in.before(dayAfter);
    }


    /**
     * Determines and answers if the day of the given {@code Date}
     * is in the future.
     *
     * @param date   the date to check
     * @return {@code true} if in the future, {@code false} otherwise
     */
    public static boolean isFutureDay(Date date) {
        Calendar in = new GregorianCalendar();
        in.setTime(date);
        Calendar tomorrow = getRelativeCalendar(+1);
        return !in.before(tomorrow);
    }


    /**
     * Computes the day that has the given offset in days to today
     * and returns it as an instance of  {@code Date}.
     *
     * @param offsetDays   the offset in day relative to today
     * @return the {@code Date} that is the begin of the day
     *     with the specified offset
     */
    public static Date getRelativeDate(int offsetDays) {
        return getRelativeCalendar(offsetDays).getTime();
    }


    /**
     * Computes the day that has the given offset in days to today
     * and returns it as an instance of {@code Calendar}.
     *
     * @param offsetDays   the offset in day relative to today
     * @return a {@code Calendar} instance that is the begin of the day
     *     with the specified offset
     */
    public static Calendar getRelativeCalendar(int offsetDays) {
        Calendar today = new GregorianCalendar();
        return getRelativeCalendar(today, offsetDays);
    }


    /**
     * Computes the day that has the given offset in days from the specified
     * <em>from</em> date and returns it as an instance of {@code Calendar}.
     *
     * @param from         the base date as {@code Calendar} instance
     * @param offsetDays   the offset in day relative to today
     * @return a {@code Calendar} instance that is the begin of the day
     *     with the specified offset from the given day
     */
    public static Calendar getRelativeCalendar(Calendar from, int offsetDays) {
        Calendar temp =
            new GregorianCalendar(
                from.get(Calendar.YEAR),
                from.get(Calendar.MONTH),
                from.get(Calendar.DATE),
                0,
                0,
                0);
        temp.add(Calendar.DATE, offsetDays);
        return temp;
    }

}
